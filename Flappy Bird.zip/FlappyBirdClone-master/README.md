# FlappyBirdClone
A Flappy Bird clone using p5.js and Matter.js
